<?php if(!defined('PLX_ROOT')) exit; ?>

	<div id="pied_de_page">
						<a href="#">Mon thème par Admox</a>
					</div>
	
	</div></div></div>
	
	<div id="CBG"></div><div id="CBD"></div><div id="BB"></div>
	
	</div>

</body>
</html>
